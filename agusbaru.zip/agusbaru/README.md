# ```RizzModz-Api```
<p align="center">
<a href="https://github.com/rizkystoreoffc/followers"><img title="Followers" src="https://img.shields.io/github/followers/rizkystoreoffc?color=red&style=flat-square"></a>
<a href="https://github.com/rizkystoreoffc/my-rest-api/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/rizkystoreoffc/my-rest-api?color=blue&style=flat-square"></a>
<a href="https://github.com/rizkystoreoffc/my-rest-api/network/members"><img title="Forks" src="https://img.shields.io/github/forks/rizkystoreoffc/my-rest-api?color=red&style=flat-square"></a>
<a href="https://github.com/rizkystoreoffc/my-rest-api/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/rizkystoreoffc/my-rest-api?label=Watchers&color=blue&style=flat-square"></a>
<a href="https://github.com/rizkystoreoffc/my-rest-api"><img title="Open Source" src="https://badges.frapsoft.com/os/v2/open-source.svg?v=103"></a>
<a href="https://github.com/rizkystoreoffc/my-rest-api/"><img title="Size" src="https://img.shields.io/github/repo-size/rizkystoreoffc/my-rest-api?style=flat-square&color=green"></a>
<a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2Frizkystoreoffc%2FRest-my-rest-api&count_bg=%2379C83D&title_bg=%23555555&icon=probot.svg&icon_color=%2300FF6D&title=hits&edge_flat=false"/></a>
<a href="https://github.com/rizkystoreoffc/my-rest-api/graphs/commit-activity"><img height="20" src="https://img.shields.io/badge/Maintained%3F-yes-green.svg"></a>&nbsp;&nbsp;
</p>
<p align='center'>
    </p>

-------
<h1 align="center">assalamu'alaikum <img src="https://user-images.githubusercontent.com/1303154/88677602-1635ba80-d120-11ea-84d8-d263ba5fc3c0.gif" width="40px" alt="hi"><br>I'm Rizkystoreoffc 😇 </h1>
<p align="center">
  <img src="https://github.com/rizkystoreoffc.png" /></>
</p>

- 👼 My name is Rizkyy
- 🗣️ I am 17 years old 
- 🔭 I am not programmer

## ```Connect with me```
<p align="center">
  <a href="https://instagram.com/rizzmodzofc"><img src="https://img.shields.io/badge/Instagram-E4405F?style=for-the-badge&logo=instagram&logoColor=white"/> 
  <a href="https://wa.me/62895328298685"><img src="https://img.shields.io/badge/WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
  <a href="https://www.facebook.com/profile.php?id=100015526687857"><img src="https://img.shields.io/badge/Facebook-%234267B2.svg?&style=for-the-badge&logo=facebook&logoColor=white" />
  <a href="https://t.me/rizkystoreoffc"><img src="https://img.shields.io/badge/Telegram-%230088cc.svg?&style=for-the-badge&logo=telegram&logoColor=white" /> <br>
  <a href="https://github.com/rizkystoreoffc"><img src="https://img.shields.io/badge/-GitHub-black?style=flat-square&logo=github" /> 
  <a href="https://youtube.com/channel/UCdzWwbApjkyODby7_MoRYlA"><img src="https://img.shields.io/youtube/channel/subscribers/UCdzWwbApjkyODby7_MoRYlA?style=social" /> <br>
  <a href="https://komarev.com/ghpvc/?username=rizkystoreoffc&color=blue&style=flat-square&label=Profile+Dilihat"><img src="https://komarev.com/ghpvc/?username=rizkystoreoffc&color=blue&style=flat-square&label=Profile+Dilihat" />

</p>

## ```HOW TO INSTALL```

# Cyclic App
[![Deploy to Cyclic](https://deploy.cyclic.app/button.svg)](https://app.cyclic.sh/#/join/rizkystoreoffc)

[`Click Here For Tutorial`](https://youtu.be/FqgjPDqWsF0)

<p align="center">
  <a href="https://youtu.be/FqgjPDqWsF0"><img src="https://telegra.ph/file/65daaa8264afddd90ccb5.jpg" />
</p>

# Railway App
[![Deploy to Railway](https://railway.app/button.svg)](https://railway.app?referralCode=zeeoneofc)

[`Click Here For Tutorial`](https://youtu.be/FqgjPDqWsF0)

<p align="center">
  <a href="https://youtu.be/FqgjPDqWsF0"><img src="https://telegra.ph/file/65daaa8264afddd90ccb5.jpg" />
</p>

# Replit App
[![Run on Repl.it](https://repl.it/badge/github/rizkystoreoffc/Rizzbot-Md)](https://replit.com)

[`Click Here For Tutorial`](https://youtu.be/FqgjPDqWsF0)

<p align="center">
  <a href="https://youtu.be/FqgjPDqWsF0"><img src="https://telegra.ph/file/65daaa8264afddd90ccb5.jpg" />
</p>


## ```Coffee ☕```

- [`SAWERIA`](https://saweria.co/rizkyystore)

## ```Thanks To```

- [`Zahir`]()
- [`Eka`]()
- [`Loli Killer`]()
- [`Rynz`]()
- [`Creative Team`]()
- [`Danzzcoding`]()
- [`RizkyyOfc`]()
